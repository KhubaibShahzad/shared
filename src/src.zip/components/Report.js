import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Table, Button, Card, Row, Col } from 'reactstrap';

import ReportModal from './ReportModal';

import './Report.css';

var instance = null;
class Report extends Component {

    constructor(props) {
        super(props);

        instance = this;

    }

    render() {

        const children = this.props.children || null;

        return (
            <div>
                <div className="clearfix">
                    <h2 className="text-success float-left">{this.props.title}</h2>
                    {
                        typeof this.props.actions != 'undefined' ? this.props.actions.map( (action, aindex) => <Button key={aindex} color="success" className="float-right" onClick={action.fnClick}>{action.title}</Button>) : null
                    }
                </div>
                <Card>
                    <Row>
                        <Col>
                            <Table hover={true} dark={true} className="table-no--mb">
                                <thead>
                                    <tr>
                                        {
                                            typeof this.props.cols != 'undefined' ? this.props.cols.map((col, cindex) => <th key={cindex}>{col.title}</th>) : null
                                        }
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        typeof this.props.rows != 'undefined' ? this.props.rows.map( (row, rindex) => {
                                            return(
                                                <tr key={rindex}>
                                                    {instance.props.cols.map( (col, cindex) => <td key={cindex}>{row[col.id]}</td>)}
                                                    <td key={instance.props.cols.length}>
                                                        {
                                                            typeof this.props.ractions != 'undefined' ? this.props.ractions.map((raction, raindex) => <span key={raindex} className="report-action-button" onClick={this.fnToggleModal}>{raction.title}</span>) : null
                                                        }
                                                    </td>
                                                </tr>
                                            )
                                        }) : null
                                    }
                                </tbody>
                            </Table>
                        </Col>
                    </Row>
                </Card>                
            </div>
        )
    }
}


export default connect()(Report);