import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

var instance = null;
class ReportModal extends Component {

    constructor(props) {
        super(props);

        this.state = {
            modal: false
        }

        this.fnToggleModal = this.fnToggleModal.bind(this);
        instance = this;
    }

    componentDidMount(){
        this.setState({
            modal: this.props.isOpen
        })
    }

    componentDidUpdate(prevProps) {
        if(this.props.isOpen != prevProps.isOpen){
            this.setState({
                modal: this.props.isOpen
            })
        }
        
    }

    fnToggleModal(){
        this.setState({
            modal: !this.state.modal
        })

        this.props.cbToggle(!this.state.modal)
    }

    render() {

        const children = this.props.children || null;
        return (
            <Modal size="lg" isOpen={this.state.modal} toggle={this.fnToggleModal}>
                <ModalHeader toggle={this.fnToggleModal}><h3>Assistance In</h3></ModalHeader>
                <ModalBody>
                    {this.props.body}
                </ModalBody>
                <ModalFooter>
                    {this.props.footer}
                </ModalFooter>
            </Modal>
        )
    }
}


export default connect()(ReportModal);