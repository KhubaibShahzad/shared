import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Row, Col, FormGroup, Label, Input, FormText, InputGroup, InputGroupAddon, InputGroupText } from 'reactstrap';


class AssistanceInForm extends Component {

    constructor(props) {
        super(props);
        
    }

    render() {
        
        return (
            <div>
                <Row>
                    <Col xs="6">
                        <FormGroup>
                            <Label for="exampleEmail">Recipient</Label>
                            <Row>
                                <Col xs="6">
                                    <Input type="text" name="email" id="exampleEmail" placeholder="" bsSize="sm"/>
                                    <FormText>First Name</FormText>
                                </Col>
                                <Col xs="6">
                                    <Input type="text" name="email" id="exampleEmail" placeholder="" bsSize="sm"/>
                                    <FormText>Last Name</FormText>
                                </Col>
                            </Row>
                        </FormGroup>
                    </Col>
                    <Col xs="6">
                        <FormGroup>
                            <Label for="exampleEmail">Person Providing Assistance</Label>
                            <Row>
                                <Col xs="6">
                                    <Input type="text" name="email" id="exampleEmail" placeholder="" bsSize="sm"/>
                                    <FormText>First Name</FormText>
                                </Col>
                                <Col xs="6">
                                    <Input type="text" name="email" id="exampleEmail" placeholder="" bsSize="sm"/>
                                    <FormText>Last Name</FormText>
                                </Col>
                            </Row>
                        </FormGroup>
                    </Col>
                </Row>
                <Row>
                    <Col xs="6">
                        <FormGroup>
                            <Label for="exampleSelect">Relationship</Label>
                            <Input type="select" name="select" id="exampleSelect">
                                <option>Aunt</option>
                                <option>Charity</option>
                                <option>Child</option>
                                <option>Cousin</option>
                                <option>Friend</option>
                                <option>Grandchild</option>
                                <option>Grandparent</option>
                                <option>In-Law</option>
                                <option>Nephew</option>
                                <option>Niece</option>
                                <option>Other</option>
                                <option>Parent</option>
                                <option>Sibling</option>
                                <option>Step-Grandparent</option>
                                <option>Step-Parent</option>
                                <option>Step-Sibling</option>
                                <option>Uncle</option>
                            </Input>
                        </FormGroup>
                    </Col>
                    <Col xs="6">
                        <Label for="exampleEmail">Amount Received</Label>
                        <InputGroup>
                            <Input placeholder="Amount" min={0} max={100} type="number" step="1" />
                            <InputGroupAddon addonType="append">$</InputGroupAddon>
                        </InputGroup>
                    </Col>
                </Row>
                <Row>
                    <Col xs="6">
                        <FormGroup>
                            <Label for="exampleSelect">Frequency</Label>
                            <Input type="select" name="select" id="exampleSelect">
                                <option>Monthly</option>
                                <option>Quarterly</option>
                                <option>Annually</option>
                                <option>One-Time</option>
                            </Input>
                        </FormGroup>
                    </Col>
                    <Col xs="6">
                        <FormGroup>
                            <Label for="exampleSelect">Goal Being Funded</Label>
                            <Input type="select" name="select" id="exampleSelect">
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                            </Input>
                        </FormGroup>
                    </Col>
                </Row>
                <Row>
                    <Col xs="6">
                        <FormGroup>
                            <Label for="exampleDate">Estimated Start Date</Label>
                            <Input
                            type="date"
                            name="date"
                            id="exampleDate"
                            placeholder="date placeholder"
                            />
                        </FormGroup>
                    </Col>                    
                </Row>
                <Row>
                    <Col xs="6">
                        <FormGroup>
                            <Label for="exampleDate">Assistance Ends</Label>
                            <Row>
                                <Col xs="6">
                                    <FormGroup check>
                                        <Label check>
                                        <Input type="radio" name="radio2" />{' '}
                                        At Retirement
                                        </Label>
                                    </FormGroup>
                                </Col>
                                <Col xs="6">
                                    <FormGroup check>
                                        <Label check>
                                        <Input type="radio" name="radio2" />{' '}
                                        At Spouse Retirement
                                        </Label>
                                    </FormGroup>
                                </Col>
                            </Row>
                            <Row>
                                <Col xs="6">
                                    <FormGroup check>
                                        <Label check>
                                        <Input type="radio" name="radio2" />{' '}
                                        At Death
                                        </Label>
                                    </FormGroup>
                                </Col>
                                <Col xs="6">
                                    <FormGroup check>
                                        <Label check>
                                        <Input type="radio" name="radio2" />{' '}
                                        Another Date
                                        </Label>
                                    </FormGroup>
                                </Col>
                            </Row>
                        </FormGroup>
                    </Col>    
                    <Col xs="6">
                        <FormGroup>
                            <Label for="exampleDate">Estimated End Date</Label>
                            <Input
                            type="date"
                            name="date"
                            id="exampleDate"
                            placeholder="date placeholder"
                            />
                        </FormGroup>
                    </Col>                     
                </Row>

                <Row>
                    <Col xs="6">
                        <Label for="exampleEmail">Total Amount Received</Label>
                        <InputGroup>
                            <Input placeholder="Amount" min={0} max={100} type="number" step="1" />
                            <InputGroupAddon addonType="append">$</InputGroupAddon>
                        </InputGroup>
                    </Col>           
                </Row>
            </div>
            
        )
    }
}


export default connect()(AssistanceInForm);