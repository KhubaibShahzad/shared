import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Button, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';

import Loader from '../../components/Loader';
import Report from '../../components/Report';
import AssistanceInModal from './AssistanceInModal';

const MODAL = {
    ASSISTANCE_CURRENT: 'modal_assistance',
    ASSISTANCE_FUTURE: 'modal_assistance_future',
}

class AssistanceReceived extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isOpenCurrent: true,
            isOpenFuture: false
        };

        this.fnAddCurrent = this.fnAddCurrent.bind(this);
        this.fnEditCurrent = this.fnEditCurrent.bind(this);

        this.fnToggleModal = this.fnToggleModal.bind(this);
    }

    fnAddCurrent(){
        console.log('Add');
        this.fnToggleModal(MODAL.ASSISTANCE_CURRENT);
    }

    fnEditCurrent(){
        console.log('Edit');
    }

    fnToggleModal(modal){
        if(modal == MODAL.ASSISTANCE_CURRENT){
            this.setState({
                isOpenCurrent: !this.state.isOpenCurrent
            })
        }
        else if(modal == MODAL.ASSISTANCE_FUTURE){
            this.setState({
                isOpenFuture: !this.state.isOpenFuture
            })
        }
        
    }

    render() {
        var report_cols = [
            {
                id: 'recipient',
                title: 'Recipient'
            },
            {
                id: 'person_providing_assistance',
                title: 'Person Providing Assistance'
            },
            {
                id: 'amount_received',
                title: 'Amount Received'
            },
            {
                id: 'estimated_start_date',
                title: 'Estimated Start Date'
            },
            {
                id: 'estimated_end_data',
                title: 'Estimated End Data'
            },
            {
                id: 'total_amount_received',
                title: 'Total Amount Received'
            }
        ];

        var report_rows = [
            {
                recipient: 'Frank Jones',
                person_providing_assistance: 'Gary Smith',
                amount_received: '$10, 000',
                estimated_start_date: '07/12/2019',
                estimated_end_data: '07/12/2020',
                total_amount_received: '$0.00',
            },
            {
                recipient: 'Frank Jones',
                person_providing_assistance: 'Shara Tomas',
                amount_received: '$1,000',
                estimated_start_date: '07/16/2019',
                estimated_end_data: '07/17/2019',
                total_amount_received: '$0.00',
            },
            {
                recipient: '',
                person_providing_assistance: '',
                amount_received: '$100 Monthly',
                estimated_start_date: '08/16/2019',
                estimated_end_data: '01/01/2040',
                total_amount_received: '$0.00',
            },
            {
                recipient: 'Frank Jones',
                person_providing_assistance: 'Shara Tomas',
                amount_received: '$100 Monthly',
                estimated_start_date: '09/13/2019',
                estimated_end_data: '01/01/2023',
                total_amount_received: '$4,100',
            },
            {
                recipient: 'Ava Jones',
                person_providing_assistance: 'Bob Charles',
                amount_received: '$125 Monthly',
                estimated_start_date: '09/13/2019',
                estimated_end_data: '01/01/2022',
                total_amount_received: '$3,625',
            },
        ]

        var report_actions = [
            {
                title: 'Add',
                fnClick: this.fnAddCurrent
            }
        ]

        var row_actions = [
            {
                title: 'Edit',
                fnClick: this.fnEditCurrent
            }
        ]
        return (
            <React.Fragment>
                <div className="fragment-assitance-received">
                    { /* preloader */}
                    {this.props.loading && <Loader />}
                    
                    <Report 
                        cols={report_cols} 
                        rows={report_rows}
                        title="Current Assistance"
                        actions={report_actions}
                        ractions={row_actions}
                    >
                    </Report>
                    <AssistanceInModal
                        isOpen={this.state.isOpenCurrent}
                        cbToggle={(toggle) => this.setState({isOpenCurrent: toggle})}
                    ></AssistanceInModal>
                    <Report 
                        cols={report_cols} 
                        rows={report_rows}
                        title="Future Assistance"
                    ></Report>

                </div>
            </React.Fragment>
        )
    }
}


export default connect()(AssistanceReceived);