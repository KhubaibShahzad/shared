import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Row, Button } from 'reactstrap';
import ReportModal from '../../components/ReportModal';
import AssistanceInForm from './AssistanceInForm';

class AssistanceInModal extends Component {

    constructor(props) {
        super(props);
        
    }

    renderBody(){
        return (
            <AssistanceInForm></AssistanceInForm>
        )
    }

    renderFooter(){
        return (
            <div>
                <Button color="success" className="" >Save</Button>{' '}
                <Button color="secondary" className="" >Reset</Button>
            </div>
        )
    }

    render() {
        
        return (
            <ReportModal
                isOpen={this.props.isOpen}
                cbToggle={this.props.cbToggle}
                body={this.renderBody()}
                footer={this.renderFooter()}
            ></ReportModal>
        )
    }
}


export default connect()(AssistanceInModal);