import { combineReducers } from 'redux';
import Auth from './auth/reducers';

export default combineReducers({
    Auth
});